#!/bin/bash
cd ai_service
python app.py